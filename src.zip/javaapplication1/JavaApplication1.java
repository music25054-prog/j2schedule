package javaapplication1;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class JavaApplication1 extends MIDlet implements CommandListener {
    private Display display;
    
    private Form mainForm;
    private TextField timeField;
    private TextField taskField;
    private List scheduleList;
    
    private Command addCommand;
    private Command viewCommand;
    private Command backCommand;
    private Command exitCommand;

    public JavaApplication1() {
        display = Display.getDisplay(this);
        
        mainForm = new Form("Новая задача");
        timeField = new TextField("Время (напр. 09:00):", "", 10, TextField.ANY);
        taskField = new TextField("Описание задачи:", "", 50, TextField.ANY);
        
        addCommand = new Command("Добавить", Command.SCREEN, 1);
        viewCommand = new Command("Расписание", Command.SCREEN, 2);
        exitCommand = new Command("Выход", Command.EXIT, 3);
        
        mainForm.append(timeField);
        mainForm.append(taskField);
        mainForm.addCommand(addCommand);
        mainForm.addCommand(viewCommand);
        mainForm.addCommand(exitCommand);
        mainForm.setCommandListener(this);
        
        // Используем List.MULTIPLE для создания чекбоксов у элементов списка
        scheduleList = new List("Расписание на день", List.MULTIPLE);
        backCommand = new Command("Назад", Command.BACK, 1);
        scheduleList.addCommand(backCommand);
        scheduleList.setCommandListener(this);
    }

    public void startApp() {
        display.setCurrent(mainForm);
    }

    public void pauseApp() {}

    public void destroyApp(boolean unconditional) {}

    public void commandAction(Command c, Displayable d) {
        if (c == exitCommand) {
            destroyApp(false);
            notifyDestroyed();
        } else if (c == addCommand) {
            String time = timeField.getString();
            String task = taskField.getString();
            
            if (time.length() > 0 && task.length() > 0) {
                // Добавляем задачу в список
                scheduleList.append(time + " - " + task, null);
                // Сбрасываем чекбокс нового элемента в невыбранное состояние
                int lastIndex = scheduleList.size() - 1;
                scheduleList.setSelectedIndex(lastIndex, false);
                
                timeField.setString("");
                taskField.setString("");
                display.setCurrent(scheduleList);
            }
        } else if (c == viewCommand) {
            display.setCurrent(scheduleList);
        } else if (c == backCommand) {
            display.setCurrent(mainForm);
        }
    }
}