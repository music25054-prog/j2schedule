import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.Date;
import java.util.Calendar;

public class J2Schedule extends MIDlet implements CommandListener {
    private Display display;
    private Form mainForm;
    private TextField taskField;
    private DateField timeField;
    private List taskList;
    private Command addCmd, viewListCmd, backCmd, deleteCmd, exitCmd;
    
    private static final String STORE_NAME = "ScheduleStore";

    public J2Schedule() {
        display = Display.getDisplay(this);
        
        mainForm = new Form("Новая задача");
        
        timeField = new DateField("Время:", DateField.TIME);
        timeField.setDate(new Date());
        
        taskField = new TextField("Описание задачи:", "", 50, TextField.ANY);
        
        mainForm.append(timeField);
        mainForm.append(taskField);
        
        addCmd = new Command("Добавить", Command.ITEM, 1);
        viewListCmd = new Command("Список задач", Command.SCREEN, 2);
        exitCmd = new Command("Выход", Command.EXIT, 3);
        
        mainForm.addCommand(addCmd);
        mainForm.addCommand(viewListCmd);
        mainForm.addCommand(exitCmd);
        mainForm.setCommandListener(this);
        
        // Экран со списком задач с чекбоксами (Choice.MULTIPLE)
        taskList = new List("Мое расписание", Choice.MULTIPLE);
        backCmd = new Command("Назад", Command.BACK, 1);
        deleteCmd = new Command("Удалить", Command.ITEM, 2);
        
        taskList.addCommand(backCmd);
        taskList.addCommand(deleteCmd);
        taskList.setCommandListener(this);
        
        // Загружаем сохраненные задачи при запуске
        loadTasks();
    }
    
    public void startApp() {
        display.setCurrent(mainForm);
    }
    
    public void pauseApp() {
        saveTasks(); // Сохраняем при сворачивании
    }
    
    public void destroyApp(boolean unconditional) {
        saveTasks(); // Сохраняем при закрытии
    }
    
    public void commandAction(Command c, Displayable d) {
        if (c == addCmd) {
            String taskText = taskField.getString();
            if (taskText == null || taskText.trim().length() == 0) {
                Alert alert = new Alert("Ошибка", "Введите описание задачи!", null, AlertType.ERROR);
                display.setCurrent(alert, mainForm);
                return;
            }
            
            Date selectedDate = timeField.getDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(selectedDate);
            
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            
            String timeStr = (hour < 10 ? "0" : "") + hour + ":" + (minute < 10 ? "0" : "") + minute;
            String listItem = timeStr + " - " + taskText.trim();
            
            taskList.append(listItem, null);
            taskField.setString("");
            
            saveTasks(); // Сохраняем сразу после добавления
            display.setCurrent(taskList);
            
        } else if (c == viewListCmd) {
            display.setCurrent(taskList);
            
        } else if (c == backCmd) {
            display.setCurrent(mainForm);
            
        } else if (c == deleteCmd) {
            boolean deleted = false;
            for (int i = taskList.size() - 1; i >= 0; i--) {
                if (taskList.isSelected(i)) {
                    taskList.delete(i);
                    deleted = true;
                }
            }
            if (!deleted) {
                int selectedIndex = taskList.getSelectedIndex();
                if (selectedIndex != -1) {
                    taskList.delete(selectedIndex);
                }
            }
            
            saveTasks(); // Сохраняем после удаления
            
        } else if (c == exitCmd) {
            saveTasks();
            notifyDestroyed();
        }
    }
    
    // Метод сохранения задач в RMS
    private void saveTasks() {
        RecordStore rs = null;
        try {
            RecordStore.deleteRecordStore(STORE_NAME);
        } catch (Exception e) {}
        
        try {
            rs = RecordStore.openRecordStore(STORE_NAME, true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            
            int size = taskList.size();
            dos.writeInt(size);
            for (int i = 0; i < size; i++) {
                dos.writeUTF(taskList.getString(i));
                dos.writeBoolean(taskList.isSelected(i));
            }
            
            byte[] data = baos.toByteArray();
            rs.addRecord(data, 0, data.length);
            rs.closeRecordStore();
        } catch (Exception e) {
            try { if (rs != null) rs.closeRecordStore(); } catch (Exception ex) {}
        }
    }
    
    // Метод загрузки задач из RMS
    private void loadTasks() {
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore(STORE_NAME, false);
            if (rs.getNumRecords() > 0) {
                byte[] data = rs.getRecord(1);
                ByteArrayInputStream bais = new ByteArrayInputStream(data);
                DataInputStream dis = new DataInputStream(bais);
                
                int size = dis.readInt();
                for (int i = 0; i < size; i++) {
                    String text = dis.readUTF();
                    boolean selected = dis.readBoolean();
                    taskList.append(text, null);
                    taskList.setSelectedIndex(i, selected);
                }
            }
            rs.closeRecordStore();
        } catch (Exception e) {
            try { if (rs != null) rs.closeRecordStore(); } catch (Exception ex) {}
        }
    }
}