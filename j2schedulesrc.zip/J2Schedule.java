import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.Date;
import java.util.Calendar;

public class J2Schedule extends MIDlet implements CommandListener {
    private Display display;
    private Form mainForm;
    private TextField taskField;
    private DateField timeField;
    private List taskList;
    private Command addCmd, viewListCmd, backCmd, deleteCmd, exitCmd;
    
    public J2Schedule() {
        display = Display.getDisplay(this);
        
        mainForm = new Form("Новая задача");
        
        timeField = new DateField("Время:", DateField.TIME);
        timeField.setDate(new Date());
        
        taskField = new TextField("Описание задачи:", "", 50, TextField.ANY);
        
        mainForm.append(timeField);
        mainForm.append(taskField);
        
        addCmd = new Command("Добавить", Command.ITEM, 1);
        viewListCmd = new Command("Список задач", Command.SCREEN, 2);
        exitCmd = new Command("Выход", Command.EXIT, 3);
        
        mainForm.addCommand(addCmd);
        mainForm.addCommand(viewListCmd);
        mainForm.addCommand(exitCmd);
        mainForm.setCommandListener(this);
        
        taskList = new List("Мое расписание", Choice.MULTIPLE);
        backCmd = new Command("Назад", Command.BACK, 1);
        deleteCmd = new Command("Удалить", Command.ITEM, 2);
        
        taskList.addCommand(backCmd);
        taskList.addCommand(deleteCmd);
        taskList.setCommandListener(this);
    }
    
    public void startApp() {
        display.setCurrent(mainForm);
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {}
    
    public void commandAction(Command c, Displayable d) {
        if (c == addCmd) {
            String taskText = taskField.getString();
            if (taskText == null || taskText.trim().length() == 0) {
                Alert alert = new Alert("Ошибка", "Введите описание задачи!", null, AlertType.ERROR);
                display.setCurrent(alert, mainForm);
                return;
            }
            
            Date selectedDate = timeField.getDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(selectedDate);
            
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            
            String timeStr = (hour < 10 ? "0" : "") + hour + ":" + (minute < 10 ? "0" : "") + minute;
            String listItem = timeStr + " - " + taskText.trim();
            
            taskList.append(listItem, null);
            taskField.setString("");
            display.setCurrent(taskList);
            
        } else if (c == viewListCmd) {
            display.setCurrent(taskList);
            
        } else if (c == backCmd) {
            display.setCurrent(mainForm);
            
        } else if (c == deleteCmd) {
            // Надежное удаление: сначала удаляем все отмеченные галочками задачи
            boolean deleted = false;
            for (int i = taskList.size() - 1; i >= 0; i--) {
                if (taskList.isSelected(i)) {
                    taskList.delete(i);
                    deleted = true;
                }
            }
            // Если галочки не стояли, удаляем текущий выбранный (подсвеченный) элемент
            if (!deleted) {
                int selectedIndex = taskList.getSelectedIndex();
                if (selectedIndex != -1) {
                    taskList.delete(selectedIndex);
                }
            }
            
        } else if (c == exitCmd) {
            notifyDestroyed();
        }
    }
}